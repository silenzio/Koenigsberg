package test;

import Fenster.Hauptfenster;

public class Start {
	public static void main(String[] args) {
		Hauptfenster anwendung = new Hauptfenster();
		anwendung.setVisible(true);
	}
}
